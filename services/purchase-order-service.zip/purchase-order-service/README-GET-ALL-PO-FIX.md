# Purchase Order Service - GET All POs Fix

## GET all Purchase Orders

`GET /api/v1/purchase-orders`

The `status` query parameter has been removed.

Supported optional filters:
- `vendorName`
- `projectId`
- `departmentName`

Examples:
- `/api/v1/purchase-orders`
- `/api/v1/purchase-orders?vendorName=3D`
- `/api/v1/purchase-orders?projectId=P-1`
- `/api/v1/purchase-orders?departmentName=Software`
- `/api/v1/purchase-orders?vendorName=3D&projectId=P-1&departmentName=Software`

When multiple filters are supplied, all are applied with AND semantics.

The status field remains part of the Purchase Order response; only status filtering was removed from the GET-all request.

## Build

From the repository root:

```powershell
.\gradlew :services:purchase-order-service:clean build
```
