package com.recnaile.purchaseorder;

import com.recnaile.purchaseorder.domain.model.PurchaseOrder;
import com.recnaile.purchaseorder.repository.PurchaseOrderRepository;
import com.recnaile.purchaseorder.service.PurchaseOrderQueryService;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class PurchaseOrderQueryServiceTest {

    @Test
    void departmentNameFilterIsOptionalAndUsesDepartmentRepositoryQuery() {
        PurchaseOrderRepository repository = mock(PurchaseOrderRepository.class);
        PurchaseOrderQueryService service = new PurchaseOrderQueryService(repository);
        List<PurchaseOrder> expected = List.of(new PurchaseOrder());
        when(repository.findByDepartmentName("Software")).thenReturn(expected);

        assertThat(service.find(null, null, "Software")).isSameAs(expected);
        verify(repository).findByDepartmentName("Software");
    }
}
