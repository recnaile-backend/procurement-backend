package com.recnaile.purchaseorder.repository;

import com.recnaile.purchaseorder.domain.enums.PurchaseOrderStatus;
import com.recnaile.purchaseorder.domain.model.PurchaseOrder;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface PurchaseOrderRepository extends MongoRepository<PurchaseOrder, String> {

    List<PurchaseOrder> findByStatus(PurchaseOrderStatus status);

    List<PurchaseOrder> findByVendorNameAndStatus(String vendorName, PurchaseOrderStatus status);

    List<PurchaseOrder> findByVendorName(String vendorName);

    List<PurchaseOrder> findByDepartmentName(String departmentName);

    List<PurchaseOrder> findByDepartmentNameAndStatus(String departmentName, PurchaseOrderStatus status);

    List<PurchaseOrder> findByProjectIdAndStatus(String projectId, PurchaseOrderStatus status);

    List<PurchaseOrder> findByProjectId(String projectId);

    List<PurchaseOrder> findBySourceIndentIdsIn(Collection<String> sourceIndentIds);
    List<PurchaseOrder> findByVendorNameAndProjectId(String vendorName, String projectId);

    List<PurchaseOrder> findByVendorNameAndDepartmentName(String vendorName, String departmentName);

    List<PurchaseOrder> findByProjectIdAndDepartmentName(String projectId, String departmentName);

    List<PurchaseOrder> findByVendorNameAndProjectIdAndDepartmentName(String vendorName, String projectId, String departmentName);
}
