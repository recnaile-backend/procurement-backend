package com.recnaile.purchaseorder.service;

import com.recnaile.purchaseorder.domain.model.PurchaseOrder;
import com.recnaile.purchaseorder.repository.PurchaseOrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PurchaseOrderQueryService {

    private final PurchaseOrderRepository repository;

    public PurchaseOrderQueryService(PurchaseOrderRepository repository) {
        this.repository = repository;
    }

    public PurchaseOrder getById(String poId) {
        return repository.findById(poId)
                .orElseThrow(() -> new com.recnaile.purchaseorder.exception.ResourceNotFoundException(
                        "PO_NOT_FOUND", "Purchase Order not found: " + poId));
    }

    public List<PurchaseOrder> find(String vendorName, String projectId, String departmentName) {
        boolean hasVendor = vendorName != null && !vendorName.isBlank();
        boolean hasProject = projectId != null && !projectId.isBlank();
        boolean hasDepartment = departmentName != null && !departmentName.isBlank();

        if (hasVendor && hasProject && hasDepartment) {
            return repository.findByVendorNameAndProjectIdAndDepartmentName(
                    vendorName.trim(), projectId.trim(), departmentName.trim());
        }
        if (hasVendor && hasProject) {
            return repository.findByVendorNameAndProjectId(vendorName.trim(), projectId.trim());
        }
        if (hasVendor && hasDepartment) {
            return repository.findByVendorNameAndDepartmentName(vendorName.trim(), departmentName.trim());
        }
        if (hasProject && hasDepartment) {
            return repository.findByProjectIdAndDepartmentName(projectId.trim(), departmentName.trim());
        }
        if (hasVendor) {
            return repository.findByVendorName(vendorName.trim());
        }
        if (hasProject) {
            return repository.findByProjectId(projectId.trim());
        }
        if (hasDepartment) {
            return repository.findByDepartmentName(departmentName.trim());
        }
        return repository.findAll();
    }
}
