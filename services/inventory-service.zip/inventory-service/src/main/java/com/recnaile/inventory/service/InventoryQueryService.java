package com.recnaile.inventory.service;

import com.recnaile.inventory.domain.StockBalanceDocument;
import com.recnaile.inventory.domain.StockMovementDocument;
import com.recnaile.inventory.repository.StockBalanceRepository;
import com.recnaile.inventory.repository.StockMovementRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class InventoryQueryService {
    private final StockBalanceRepository balances;
    private final StockMovementRepository movements;
    public InventoryQueryService(StockBalanceRepository balances, StockMovementRepository movements){this.balances=balances;this.movements=movements;}
    public List<StockBalanceDocument> byItem(String itemId){return balances.findByItemId(itemId);}
    public List<StockMovementDocument> movements(){return movements.findAll();}
}
