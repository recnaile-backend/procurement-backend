package com.recnaile.inventory.controller;

import com.recnaile.inventory.domain.StockBalanceDocument;
import com.recnaile.inventory.service.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import java.util.List;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/inventory")
public class InventoryController {
    private final InventoryQueryService query;
    private final ThresholdService threshold;
    private final ReconciliationService reconciliation;

    public InventoryController(InventoryQueryService query,ThresholdService threshold,ReconciliationService reconciliation){
        this.query=query;this.threshold=threshold;this.reconciliation=reconciliation;
    }

    @GetMapping("/stock/{itemId}")
    public ResponseEntity<List<StockBalanceDocument>> getStock(@PathVariable String itemId){
        return ResponseEntity.ok(query.byItem(itemId));
    }

    @PutMapping("/stock/{itemId}/thresholds")
    public ResponseEntity<StockBalanceDocument> updateThresholds(@PathVariable String itemId,@Valid @RequestBody ThresholdRequest request){
        return ResponseEntity.ok(threshold.update(itemId,request.departmentId(),request.projectId(),request.location(),request.minimumStock(),request.maximumStock()));
    }

    @GetMapping("/reconciliation/{itemId}")
    public ResponseEntity<Map<String,Object>> reconcile(@PathVariable String itemId){
        return ResponseEntity.ok(reconciliation.reconcile(itemId));
    }

    public record ThresholdRequest(
        String departmentId,String projectId,String location,
        @DecimalMin(value="0.0") double minimumStock,
        @DecimalMin(value="0.0") double maximumStock) {}
}
